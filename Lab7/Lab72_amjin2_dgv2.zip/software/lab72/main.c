/*
 * main.c
 */
#include "text_mode_vga_color.h"
#include <system.h>
#include <alt_types.h>

int main(){
	textVGAColorScreenSaver();
    return 1;
}
